<?php
require('../makefont/makefont.php');
MakeFont('THSarabunNew.ttf', 'cp874');
MakeFont('THSarabunNewBold.ttf', 'cp874');
